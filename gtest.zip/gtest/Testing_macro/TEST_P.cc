#include <iostream>

#include <gtest/gtest.h>

using ::testing::TestWithParam;
using ::testing::Values;

class MyTest : public TestWithParam<int>
{
public:
    static int count;
    void SetUp() override
    {
        std::cout << ">>>> No " << count++ << " test\n";
        val = GetParam();
    }
    void TearDown() override
    {
    }

protected:
    int val;
};

int MyTest::count = 1;


INSTANTIATE_TEST_SUITE_P(my_test_p, MyTest,   Values(1, 2, 3, 4, 5));

TEST_P(MyTest, test) {
    EXPECT_LT(val, 3);
}
