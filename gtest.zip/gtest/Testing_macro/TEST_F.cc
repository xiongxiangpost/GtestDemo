#include <iostream>

#include <gtest/gtest.h>
using std::string;
class FirstGtestClass : public ::testing::Test
{
protected:
    void SetUp() override
    {
        std::cout << ">>>>> SetUp\n";
        m_arr = new int[5]{1, 2, 3, 4, 5};
    }

    void TearDown() override
    {
        std::cout << ">>>>>> TearDown\n";
        delete []m_arr;
    }

    int *m_arr;
};

TEST_F(FirstGtestClass, failureTest)
{
    EXPECT_NE(m_arr[1], 2); // 直接使用m_arr
}

TEST_F(FirstGtestClass, equalTest)
{
    EXPECT_EQ(m_arr[1], 2);
}
