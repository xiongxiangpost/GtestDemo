#include <iostream>
#include <vector>

#include <gtest/gtest.h>
#include <gmock/gmock.h>

using ::testing::AllOf;
using ::testing::EndsWith;
using ::testing::Eq;
using ::testing::Gt;
using ::testing::IsNull;
using ::testing::Lt;
using ::testing::StartsWith;

TEST(expect_that, basic)
{
    EXPECT_THAT("hello world", StartsWith("hello"));
    ASSERT_THAT(6, AllOf(Gt(5), Lt(10)));
}

TEST(expect_that, general)
{
    int a = 3;
    int *ptr = nullptr;
    EXPECT_THAT(3, Eq(a));
    EXPECT_THAT(ptr, IsNull());
}

TEST(expect_that, string)
{
    EXPECT_THAT("hello world", StartsWith("hello"));
    EXPECT_THAT("hello world", EndsWith("world"));

    EXPECT_THAT("hello world", ::testing::ContainsRegex("o.*w"));
    EXPECT_THAT("hello world", ::testing::MatchesRegex("^o.*w$"));
}

TEST(expect_that, container)
{
    std::vector<int> v{1, 2, 2, 3, 4};
    EXPECT_THAT(v, ::testing::Contains(1));
    EXPECT_THAT(v, ::testing::Contains(5)); // error
    EXPECT_THAT(v, ::testing::Contains(2).Times(2));

    std::vector<int> v1;
    EXPECT_THAT(v1, ::testing::IsEmpty());
}

TEST(expect_that, pointer)
{
    int a = 10;
    int *p = &a;
    EXPECT_THAT(a, ::testing::Address(p));
    EXPECT_THAT(p, ::testing::Pointee(a));
}

TEST(expect_that, composite)
{
    EXPECT_THAT(6, ::testing::AllOf(Gt(5), Lt(10)));
    EXPECT_THAT(2, ::testing::AnyOf(1, 2, 3, 4));
}
