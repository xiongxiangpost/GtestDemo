#include <iostream>
#include <gtest/gtest.h>
#include <exception>

int sum(int a, int b) {
	return a + b;
}

bool isTwo(int a) {
    return a == 2;
}


TEST(Comparison, boolComparison) {
    EXPECT_TRUE(isTwo(2));
    EXPECT_FALSE(isTwo(1));
}


TEST(Comparison, valueComparison) {
	EXPECT_EQ(5, sum(2, 3));	// 求合2+3=5
	EXPECT_NE(3, sum(3, 4));	// 求合3+4 != 3
    EXPECT_LT(1, sum(1, 1));
    EXPECT_LE(2, sum(1, 1));
    EXPECT_GT(6, sum(4, 1));
    EXPECT_GE(3, sum(2, 1));
}

TEST(Comparison, stringComparison) {
    std::string str("hello");
    char buf[] = "world";
	EXPECT_STREQ("hello", str.c_str());
    EXPECT_STRNE("hello", buf);

    EXPECT_STRCASEEQ("HEllo", "hello");
    EXPECT_STRCASENE("HEllo", "world");
}


TEST(Comparison, floatComparison) {
    float f = 5.0001f;
    double d = 5.0000001;
	EXPECT_FLOAT_EQ(f, 5.0001);
    EXPECT_DOUBLE_EQ(d, 5.0000001);

    EXPECT_NEAR(f, 5.0, 0.1f);
}

class MyException : public std::exception
{
  const char * what () const throw ()
  {
    return "C++ Exception";
  }
};

void throwException() {
    throw MyException();
}

TEST(Exception , exception) {
    EXPECT_THROW(throwException(),  MyException);
    EXPECT_ANY_THROW(throwException());
    EXPECT_NO_THROW([]{/* empty function*/});
}


// 判断Predicates是否返回true
TEST(Predicates, predicatesBasic) {

    auto func1 = [](int a){ return true;};
    auto func2 = [](int a, int b){ return true;};
    EXPECT_PRED1(func1, 1);
    EXPECT_PRED2(func2, 1, 2);
    // EXPECT_PRED3(pred,val1,val2,val3)
    // EXPECT_PRED4(pred,val1,val2,val3,val4)
    // EXPECT_PRED5(pred,val1,val2,val3,val4,val5)

    // ASSERT_PRED1(pred,val1)
    // ASSERT_PRED2(pred,val1,val2)
    // ASSERT_PRED3(pred,val1,val2,val3)
    // ASSERT_PRED4(pred,val1,val2,val3,val4)
    // ASSERT_PRED5(pred,val1,val2,val3,val4,val5)

}

// EXPECT_PRED的输出不是很好看，可以自定义输出格式
testing::AssertionResult AssertFoo(const char* m_expr, const char* n_expr, int m, int n) {
    if (m == n)
        return testing::AssertionSuccess();
    testing::Message msg;
    msg << m_expr << " != " << n_expr ;
    return testing::AssertionFailure(msg);
}

TEST(Predicates, predicatesFormat) {

    // EXPECT_PRED_FORMAT1(pred_formatter,val1)
    EXPECT_PRED_FORMAT2(AssertFoo, 1, 2);
    // EXPECT_PRED_FORMAT3(pred_formatter,val1,val2,val3)
    // EXPECT_PRED_FORMAT4(pred_formatter,val1,val2,val3,val4)
    // EXPECT_PRED_FORMAT5(pred_formatter,val1,val2,val3,val4,val5)

    // ASSERT_PRED_FORMAT1(pred_formatter,val1)
    // ASSERT_PRED_FORMAT2(pred_formatter,val1,val2)
    // ASSERT_PRED_FORMAT3(pred_formatter,val1,val2,val3)
    // ASSERT_PRED_FORMAT4(pred_formatter,val1,val2,val3,val4)
    // ASSERT_PRED_FORMAT5(pred_formatter,val1,val2,val3,val4,val5)
}
